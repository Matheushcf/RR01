package solucao.forma;

public class Quadrado extends Retangulo {

	public Quadrado(double lado) {
		super(lado, lado);

	}

}
