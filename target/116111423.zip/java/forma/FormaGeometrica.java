package forma;

public interface FormaGeometrica {
	
	public double area();
}
